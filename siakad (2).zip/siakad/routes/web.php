<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', 'SiteController@home');
// Route::get('/register', 'SiteController@register');
// Route::post('/postregister', 'SiteController@postregister');

Route::get('/', 'AuthController@login')->name('login');
Route::post('/postLogin', 'AuthController@postLogin');
Route::get('/logout', 'AuthController@logout');


Route::group(['middleware' => ['auth','checkRole:admin']],function(){ 
    Route::get('/santri', 'SantriController@index');
    Route::get('/guru','GuruController@index');
    Route::get('/materi','MateriController@index');
    Route::post('/santri/create','SantriController@create');
    Route::get('/santri/{id}/edit', 'SantriController@edit');
    Route::post('/santri/{id}/update', 'SantriController@update');
    Route::get('/santri/{id}/delete', 'SantriController@delete');
    Route::get('/santri/{id}/show', 'SantriController@show');
    Route::post('/santri/{id}/addnilai', 'SantriController@addnilai');
    Route::get('/santri/{id}/{idmapel}/deletenilai', 'SantriController@deletenilai');
    Route::get('/santri/exportexcel', 'SantriController@exportExcel');
    Route::get('/santri/exportpdf', 'SantriController@exportPdf');
    //guru
    Route::get('/guru/{id}/profile', 'GuruController@profile');
    Route::get('/guru/{id}/edit', 'GuruController@edit');
    Route::get('/guru/{id}/delete', 'GuruController@delete');
    Route::post('/guru/{id}/update', 'GuruController@update');
    Route::post('/guru/create','GuruController@create');
    Route::get('/materi/{id}/profile', 'MateriController@profile');
    Route::get('/materi/{id}/edit', 'MateriController@edit');
    Route::get('/materi/{id}/delete', 'MateriController@delete');
    Route::post('/materi/{id}/update', 'MateriController@update');
    Route::post('/materi/create','MateriController@create');
    //perizinan
    Route::resource('perizinan', 'PerizinanController');
    Route::post('/perizinan/print', 'PerizinanController@print');
    //keuangan
    Route::get('/kelola', 'KelolaController@index');
    Route::post('/kelola/create','KelolaController@create');
    Route::get('/kelola/{id}', 'KelolaController@edit');
    Route::post('/kelola/{id}/update', 'KelolaController@update');
    Route::get('/kelola/{id}/delete', 'KelolaController@destroy');
    //pemasukan
    Route::get('/pemasukan', 'PemasukanController@index');
    Route::get('/pemasukan/yajra', 'PemasukanController@yajra');
    Route::post('/pemasukan/store', 'PemasukanController@store');
    Route::get('/pemasukan/{id}', 'PemasukanController@edit');
    Route::put('/pemasukan/{id}', 'PemasukanController@update');
    Route::get('/pemasukan/{id}/destroy', 'PemasukanController@destroy');
    //pengeluaran
    Route::get('/pengeluaran', 'PengeluaranController@index');
    Route::get('/pengeluaran/yajra', 'PengeluaranController@yajra');
    Route::post('/pengeluaran/store', 'PengeluaranController@store');
    //laporan
    Route::get('/laporan', 'LaporanController@index');
    Route::get('/cari-laporan', 'LaporanController@cari');
    Route::get('/export-pemasukan', 'LaporanController@pemasukan');
    Route::get('/export-pengeluaran', 'LaporanController@pengeluaran');
});

Route::group(['middleware' => ['auth','checkRole:admin,santri']],function(){
    Route::get('/dashboard', 'DashboardController@index');
});

