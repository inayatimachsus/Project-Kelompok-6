<?php

return[
    'logo_url' => '/images/logo.png',
    'title' => 'Pondok Pesantren Bani Syihan Malang',
    'welcome_message' => 'Pondok Pesantren Berkualitas',
    'sub_welcome_message' => 'Jelajahi',
    'logo_url' => '/jelajahi',

    'telepon' => '0341-878201',
    'email' => 'banisyihab@gmail.com',

    'home_feature_column_line_1_title' => 'Sarana Prasarana Memadai',
    'home_feature_column_line_1_content' => 'Memiliki fasilitas yang memadai untuk mendukung kbm',
    'home_feature_column_line_1_link_text' => 'lihat fasilitas',
    'home_feature_column_line_1_title' => '/fasilitas',

    'home_feature_column_line_1_title' => 'Lingkungan yang nyaman',
    'home_feature_column_line_1_content' => 'Bersih sejuk dan nyaman',
    'home_feature_column_line_1_link_text' => 'Daftar',
    'home_feature_column_line_1_title' => '',

    'home_feature_column_line_1_title' => 'Kurikulum terstruktur',
    'home_feature_column_line_1_content' => 'Kurikulum tidak memberatkan siswa tetapi berkualitas',
    'home_feature_column_line_1_link_text' => 'lihat kurikulum',
    'home_feature_column_line_1_title' => '/kurikulum',


];