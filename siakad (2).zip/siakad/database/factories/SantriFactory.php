<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use App\Santri;
use Faker\Generator as Faker;

$factory->define(Santri::class, function (Faker $faker) {
    return [
        'user_id' => 100,
        'nama' => $faker->name,
        'gender' =>$faker->randomElement(['L','P']),
        'alamat' =>$faker->address,
        'no_telp' =>$faker->phoneNumber,
    ];
});
