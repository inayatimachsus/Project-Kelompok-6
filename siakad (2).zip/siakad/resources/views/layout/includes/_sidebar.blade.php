<!-- LEFT SIDEBAR -->
<div id="sidebar-nav" class="sidebar">
	<div class="sidebar-scroll">
		<nav>
			<ul class="nav">
				<li><a href="/dashboard" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
				@if(auth()->user()->role == 'admin')
				<li>
					<a href="#subPages" data-toggle="collapse" class="collapsed">
						<i class="lnr lnr-database"></i> <span>Data Akademik</span> 
						<i class="icon-submenu lnr lnr-chevron-left"></i>
					</a>
					<div id="subPages" class="collapse ">
						<ul class="nav">
							<li><a href="/santri" class="">Data Santri</a></li>
							<li><a href="/materi" class="">Data Pelajaran</a></li>
							<li><a href="/guru" class="">Data Guru</a></li>
						</ul>
					</div>
					<a href="#subPages3" data-toggle="collapse" class="collapsed">
						<i class="lnr lnr-layers"></i> <span>Keuangan</span> 
						<i class="icon-submenu lnr lnr-chevron-left"></i>
					</a>
					<div id="subPages3" class="collapse">
						<ul class="nav">
							<li><a href="{{url('/kelola')}}" class="">Sumber Pemasukan</a></li>
							<li><a href="{{url('/pemasukan')}}" class="">Pemasukan</a></li>
							<li><a href="{{url('/pengeluaran')}}" class="">Pengeluaran</a></li>
							<li><a href="{{url('/laporan')}}" class="">Laporan</a></li>
						</ul>
					</div>
				</li>
				<li><a href="{{url('/perizinan')}}"><i class="lnr lnr-apartment"></i> <span>Perizinan</span></a></li>
				<li><a href="page-login.html"><i class="lnr lnr-briefcase"></i>Sarana Prasarana</span></a></li>
				@endif
				</ul>
			</nav>
		</div>
	</div>
<!-- END LEFT SIDEBAR -->