<body>
    <title>Laporan Pengeluaran</title>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nominal</th>
                <th>Sumber</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            @foreach($pemasukan as $pm)
                <tr>
                    <th scope="row">{{ $loop->iteration }}</th>
                    <td>{{ date('d M Y',strtotime($pm->created_at)) }}</td>
                    <td>Rp. {{ number_format($pm->nominal,0) }}</td>
                    <td>{{ $pm->nama_pemasukan }}</td>
                    <td>{{ $pm->keterangan }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
