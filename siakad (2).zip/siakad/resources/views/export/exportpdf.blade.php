<table class="table" style="border:1px solid #ddd">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Lengkap</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Nilai</th>
        </tr>
    </thead>
    <tbody>
    @foreach($santri as $s)
        <tr>
            <th scope="row">{{ $loop->iteration }}</th>
            <td>{{$s->nama}}</td>
            <td>{{$s->gender}}</td>
            <td>{{$s->alamat}}</td>
            <td>{{$s->ratarata()}}</td>
        </tr>
    @endforeach
    </tbody>
</table>