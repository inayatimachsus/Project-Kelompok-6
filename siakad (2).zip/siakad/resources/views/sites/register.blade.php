@extends('layout.frontend')

@section('content')
	<!-- start banner Area -->
    <section class="banner-area relative about-banner" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Register				
							</h1>	
							<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="about.html"> Register</a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	
<section class="search-course-area relative" style="background: unset;">
				<div class="container">
					<div class="row justify-content-between align-items-center">
						<div class="col-lg-3 col-md-6 search-course-left">
							<h1>
								Pendaftaran E-Pondok <br>
								Lets Join us!
							</h1>
							<p>
								Dengan Pelajaran Kurikulum, dan Guru yang memadai Jadikan anak anda Shaleh Shalehah.
							</p>
						</div>
						<div class="col-lg-6 col-md-6 search-course-right section-gap">
                        {!! Form::open(['url' => '/postregister','class' => 'form-wrap']) !!}
                                <h4 class="pb-20 text-center mb-30">Register in Here</h4>
                                {!!Form::text('nama','',['class' => 'form-control','placeholder' => 'Nama Lengkap'])!!}	
                                {!!Form::text('no_telp','',['class' => 'form-control','placeholder' => 'Nomor Telepon'])!!}	
								{!!Form::email('email','',['class' => 'form-control','placeholder' => 'Masukan E-mail'])!!}					
                                {!!Form::password('password',['class' => 'form-control','placeholder' => 'Masukan Password'])!!}
                                {!!Form::textarea('alamat','',['class' => 'form-control','placeholder' => 'Alamat'])!!}
                                <div class="form-select" id="service-select">	
                                    {!!Form::select('gender', ['' => 'Pilih Gender','L' => 'Laki-laki', 'P' => 'Perempuan'],'L');!!}
                                </div>							
								<button type = "submit" class="primary-btn text-uppercase">Submit</button>
                        {!! Form::close() !!}
						</div>
					</div>
				</div>	
			</section>
			<!-- End search-course Area -->
@stop