@extends('layout.master')

@section('title', 'Pemasukan')

@section('header')
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
@endsection

@section('container')

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">

        <div class="panel">    
        <div class="panel-heading">
            <div class="card-header"><i class="lnr lnr-layers"></i> Data Pemasukan</div>
            <div class="right">
            <button type="button" class="btn add" data-toggle="modal" data-target="#exampleModal">
                <i class="lnr lnr-plus-circle"></i>
            </button>
            </div>
        </div>
        <div class="panel-body">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="table-pemasukan" width="100%" cellspacing="0">
                    <thead class ="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>Sumber</th>
                            <th>Nominal</th>
                            <th>Tanggal</th>
                            <th>Keterangan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
                </div>
                        </div>
                    </div>        
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="lnr lnr-database"></i> Insert New</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action = "/pemasukan/store" method = "POST" enctype = "multipart/form-data">
                    {{csrf_field()}}
                    <div class="form-group">
                    <div class="form-group {{$errors->has('nama') ? 'has-error' : '' }}">
					<label for="sumber">Jenis Pemasukan</label>
                        <select class="form-control" id="sumber_id" name = "sumber_id">
                        @foreach($sumber as $sid)
                            <option value = "{{$sid->id}}">{{$sid->nama_pemasukan}}</option>
                        @endforeach
                        </select>
                    </div>
                    <label for="exampleInputEmail1">Nominal</label>
                        <input type="text" class="form-control" id="nominal" aria-describedby="emailHelp" name = "nominal" value = "{{old('nominal')}}">
                        @if($errors->has('nominal'))
                        <span class ="help-block">{{$errors->first('nominal')}}</span>
                        @endif
                    </div>
                    <div class="form-group {{$errors->has('keterangan') ? 'has-error' : '' }}">
                        <label for="exampleFormControlTextarea1">Keterangan Pemasukan</label>
                         <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="keterangan">{{old('keterangan')}}</textarea>
                         @if($errors->has('keterangan'))
                         <span class ="help-block">{{$errors->first('keterangan')}}</span>
                         @endif
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('footer')
    <script>
    $(document).ready(function(){
        $('.delete').click(function(){
            var pemasukan_id = $(this).attr('pemasukan-id');
            swal({
                title: "Yakin?",
                text: "Apakah Akan di Hapus dengan ID "+pemasukan_id+"!?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                    console.log(willDelete);
                if (willDelete) {
                    window.location = "/pemasukan/"+pemasukan_id+"/delete";
                }
            });
        });

        $('#table-pemasukan').DataTable({
        processing: true,
        serverSide: true,
        searchable: true,
        ajax: "{{url('/pemasukan/yajra')}}",
        columns: [
            // or just disable search since it's not really searchable. just add searchable:false
            // {data: 'rownum', name: 'rownum'},
            {data: 'id', name: 'a.id'},
            {data: 'nama_pemasukan', name: 'b.nama_pemasukan'},
            {data: 'nominal', name: 'a.nominal'},
            {data: 'created_at', name: 'a.created_at'},
            {data: 'keterangan', name: 'a.keterangan'},
            {data: 'action', name: 'action', orderable: false, searchable: false}
            ]
        });
    })
    </script>
@endsection
