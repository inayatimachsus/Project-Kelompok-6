@extends('layout.master')

@section('title', 'Update Data')

@section('container')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
        @if(session('sukses'))
                <div class="alert alert-success" role="alert">
                    {{session('sukses')}}
                </div>
        @endif 
        <div class="panel">    
            <div class="panel-heading"><i class="lnr lnr-pencil"></i> Update</div>
        <div class="panel-body">
        <div class="row ml-3 mt-3">
            <div class="col-6">
                    <!-- Button trigger modal -->
                    <form action ="/guru/{{$guru->id}}/update" method="POST" enctype="multipart/form-data">
                        {{csrf_field()}}
                                <div class="form-group">
                                <label for="exampleInputEmail1">Nama</label>
                                    <input name = "nama" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder ="insert Name" 
                                    value = "{{$guru->nama}}">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Status</label>
                                    <textarea name = "alamat" class="form-control" id="exampleFormControlTextarea1" rows="3">{{$guru->status}}</textarea>
                                </div>
                                <div class="form-group">                       
                                <label for="exampleInputEmail1">No Telepon</label>
                                    <input name = "telepon" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder ="insert Name" 
                                    value = "{{$guru->telepon}}">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Image</label>
                                    <input type = "file" name = "avatar" class="form-control">
                                </div> 
                                <div class="modal-footer float-left">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                                <button type="submit" class="btn btn-warning">Update</button>  
                        </div>   
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
</div>


 @endsection

   