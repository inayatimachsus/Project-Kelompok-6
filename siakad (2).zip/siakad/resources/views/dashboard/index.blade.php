@extends('layout.master')

@section('title', 'Dashboard')

@section('container')

<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Data Sementara</h3>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-users"></i></span>
										<p>
											<span class="number">{{totalSantri()}}</span>
											<span class="title">Jumlah Siswa</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-user"></i></span>
										<p>
											<span class="number">{{totalGuru()}}</span>
											<span class="title">Jumlah Guru</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-book"></i></span>
										<p>
											<span class="number">{{totalMateri()}}</span>
											<span class="title">Jumlah Materi</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-money"></i></span>
										<p>
											<span class="number">{{totalSumber()}}</span>
											<span class="title">Sumber Income</span>
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
</div>
@endsection