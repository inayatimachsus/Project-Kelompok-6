@extends('layout.master')

@section('title', 'Data Santri')

@section('container')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
        <div class="panel">    
        <div class="panel-heading">
            <!-- <div class="card-header">
                <form class="form-inline my-2 my-lg-0" method = "get" action = "/santri">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name = "cari">
                <button class="btn btn-inline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div> -->
            <div class="card-header">

            <a href="/santri/exportexcel" class = "btn btn sm btn-primary ">Excel</a>
            <a href="/santri/exportpdf" class = "btn btn sm btn-primary ">PDF</a>

            <div class="right">
            <button type="button" class="btn add" data-toggle="modal" data-target="#exampleModal">
                <i class="lnr lnr-plus-circle"></i>
            </button>
            </div>
            </div>

        </div>
        <div class="panel-body">
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0" id="datatable">
                    <thead class ="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>Nomor HP</th>
                            <th>Average</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    @foreach($data_santri as $santri)
                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{$santri->nama}}</td>
                            <td>{{$santri->gender}}</td>
                            <td>{{$santri->alamat}}</td>
                            <td>{{$santri->no_telp}}</td>
                            <td>{{$santri->ratarata()}}</td>
                            <td><a href="santri/{{$santri->id}}/show" class = "btn btn-primary btn-sm"><i class="lnr lnr-eye"></i></a>
                            <!-- <a href="santri/{{$santri->id}}/edit" class = "btn btn-success btn-sm"><i class="lnr lnr-pencil"></i></a>                                        -->
                            <a href="#" class = "btn btn-danger btn-sm delete" santri-id = "{{$santri->id}}"><i class="lnr lnr-trash"></i></a></td>
                        </tr>
                    @endforeach
                    </table>

                    </div>

                    
                      <!-- Modal -->
                      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><i class="lnr lnr-database"></i> Insert New</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                            <form action = "/santri/create" method = "POST" enctype = "multipart/form-data">
                                {{csrf_field()}}
                                <div class="form-group {{$errors->has('nama') ? 'has-error' : '' }}">
                                    <label for="exampleInputEmail1">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="name" aria-describedby="emailHelp" name = "nama" value = "{{old('nama')}}">
                                    @if($errors->has('nama'))
                                        <span class ="help-block">{{$errors->first('nama')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('email') ? 'has-error' : '' }}">
                                    <label for="exampleInputEmail1">Email</label>
                                    <input type="email" class="form-control" id="name" aria-describedby="emailHelp" name = "email" value = "{{old('email')}}">
                                    @if($errors->has('email'))
                                        <span class ="help-block">{{$errors->first('email')}}</span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Pilih Salah Satu</label>
                                    <select name = "gender" class="form-control" id="gender">
                                    <option value = "L">Laki-Laki</option>
                                    <option value = "P">Perempuan</option>
                                    </select>
                                </div>
                                <div class="form-group {{$errors->has('alamat') ? 'has-error' : '' }}">
                                    <label for="exampleFormControlTextarea1">Alamat</label>
                                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="alamat">{{old('alamat')}}</textarea>
                                    @if($errors->has('alamat'))
                                        <span class ="help-block">{{$errors->first('alamat')}}</span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">No Telpon/Hp</label>
                                    <input type="text" class="form-control" id="name" aria-describedby="emailHelp" name = "no_telp">
                                </div>
                                <div class="form-group {{$errors->has('avatar') ? 'has-error' : '' }}">
                                    <label for="exampleFormControlTextarea1">Avatar</label>
                                    <input class="form-control" id="exampleFormControlTextarea1" type = "file" name="avatar">{{old('avatar')}}</input>
                                    @if($errors->has('avatar'))
                                        <span class ="help-block">{{$errors->first('avatar')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-success">Save changes</button>
                            </div>
                            </form>
                            </div>
                            </div>
                        </div>        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>  
@endsection

@section('footer')
    <script>
            $('.delete').click(function(){
            var santri_id = $(this).attr('santri-id');
            swal({
                title: "Yakin?",
                text: "Apakah Akan di Hapus dengan ID "+santri_id+"!?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                    console.log(willDelete);
                if (willDelete) {
                    window.location = "/santri/"+santri_id+"/delete";
                }
            });
        });
    </script>
@endsection
