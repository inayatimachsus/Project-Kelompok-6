<p align="center">
	<strong>
		<span style="color: #222222;">
			<span style="font-family: 'Times New Roman', serif;">
				<span style="font-size: large;">PONDOK PESANTREN &ldquo;AL - FALACH&rdquo;</span>
			</span>
		</span>
	</strong>
</p>
<p align="center">
	<span style="color: #222222;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Jl. Ikan Kali RT. 10 RW. 03 Desa Karangploso Kecamatan Karangploso Kabupaten Malang, Jawa Timur, kode pos: 123456</span>
		</span>
	</span>
</p>
<p align="center">
	<span style="color: #222222;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">website: http://www.alfalach.com/, email:&nbsp;mts-alfalach@gmail.com, no. telp/fax: (0341) 123456789</span>
		</span>
	</span>
</p>
<hr />
<p style="text-align: right;" align="left">
	<span style="font-size: medium; font-family: 'Times New Roman', serif;">Malang, 10 Februari 2020</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Nomor : 002/III/ 17 Februari 2020
				<br /> Lampiran : &ndash;
				<br /> Hal : Permohonan Izin Pulang
			</span>
		</span>
	</span>
</p>
<p>&nbsp;</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Yth. Kepala Pondok Pesantren
				<br /> Kota Temanggung
			</span>
		</span>
	</span>
</p>
<p>&nbsp;</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Dengan hormat</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Asallamualaikum Wr.Wb</span>
		</span>
	</span>
</p>
<p style="text-align: justify;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Kami selaku dewan sekolah SMA N 7 Magelang memberitahukan terkait &nbsp;dengan kegiatan lomba antar sekolah yang akan dilaksanakan pada tanggal 10 Maret dalam memperingati hari jadi sekolah. Yang akan dilaksanakan pada :</span>
		</span>
	</span>
</p>
<p style="padding-left: 30px;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Nama santri&nbsp; &nbsp; &nbsp;: {{ $santri->nama }}
				<br />Keperluan&nbsp; &nbsp; &nbsp; &nbsp; : {{ $keperluan }}
				<br /> Tanggal&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : {{ date("l, m Y") }} 
			</span>
		</span>
	</span>
</p>
<p style="text-align: justify;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Sehubungan dengan surat resmi ini, kami mengajukan permohonan izin untuk mengadakan acara kegiatan tersebut. Atas perhatian Bapak/ ibu kami ucapkan terima kasih.</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Wassalamu&rsquo;alaikum Wr. Wb.</span>
		</span>
	</span>
</p>
<p>&nbsp;</p>
<p style="text-align: center;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;"> Mengetahui,</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Pimpinan Pondok,</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">&nbsp;</span>
</p>
<p>&nbsp;</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Rio Febriandistra M. Kom</span>
		</span>
	</span>
</p>
<p align="left">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="left">&nbsp;</p>