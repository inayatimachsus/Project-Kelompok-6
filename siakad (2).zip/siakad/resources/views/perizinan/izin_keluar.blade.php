<p align="center">
	<strong>
		<span style="color: #222222;">
			<span style="font-family: 'Times New Roman', serif;">
				<span style="font-size: large;">PONDOK PESANTREN &ldquo;BANI SYIHAB&rdquo;</span>
			</span>
		</span>
	</strong>
</p>
<p align="center">
	<span style="color: #222222;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Jl. S.Supriadi Kota Malang, Jawa Timur, kode pos: 123456</span>
		</span>
	</span>
</p>

<hr />
<p style="text-align: right;" align="left">
	<span style="font-size: medium; font-family: 'Times New Roman', serif;">Malang, {{ date("l, m Y") }}</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">
				<br /> Lampiran : &ndash;
				<br /> Hal : Permohonan Izin Keluar
			</span>
		</span>
	</span>
</p>
<p>&nbsp;</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Yth. Ketua Pondok Pesantren Bani Syihab
				<br /> Kota Malang
			</span>
		</span>
	</span>
</p>
<p>&nbsp;</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Assalamualaikum Wr.Wb</span>
		</span>
	</span>
</p>
<p style="text-align: justify;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Kami wali santri pondok pesantren Bani Syihab memberitahukan bahwa santri yang dibawah ini memiliki keperluan :</span>
		</span>
	</span>
</p>
<p style="padding-left: 30px;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Nama santri&nbsp; &nbsp; &nbsp;: {{ $santri->nama }}
				<br />Keperluan&nbsp; &nbsp; &nbsp; &nbsp; : {{ $keperluan }}
				<br /> Tanggal&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : {{ date("l, m Y") }} 
			</span>
		</span>
	</span>
</p>
<p style="text-align: justify;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Sehubungan dengan surat resmi ini, kami memohonkan izin kepada bapak guru yang bertugas. Atas perhatian Bapak/ ibu kami ucapkan terima kasih.</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Wassalamu&rsquo;alaikum Wr. Wb.</span>
		</span>
	</span>
</p>
<p>&nbsp;</p>
<p style="text-align: center;">
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;"> Mengetahui,</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Guru yang memberi izin,</span>
		</span>
	</span>
</p>
<p>
	<span style="color: #000000;">&nbsp;</span>
</p>
<p>&nbsp;</p>
<p>
	<span style="color: #000000;">
		<span style="font-family: 'Times New Roman', serif;">
			<span style="font-size: medium;">Rio Febriandistra M. Kom</span>
		</span>
	</span>
</p>
<p align="left">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="left">&nbsp;</p>