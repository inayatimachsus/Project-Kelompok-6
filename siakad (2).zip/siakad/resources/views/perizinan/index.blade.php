@extends('layout.master')

@section('title', 'Perizinan')

@section('container')
<div class="container-fluid">
    <h3 class="page-title">Tables</h3>
    <div class="row">
        <div class="col-md-4">
            <!-- BASIC TABLE -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Insert perizinan</h3>
                </div>
                <div class="panel-body">
                    <form action="/perizinan/print" method="POST" enctype="multipart/form-data">
                        <fieldset>
                        {{csrf_field()}}
                            <div class="form-group row">
                                <label for="santri_id" class="col-sm-3 col-form-label">Santri</label>
                                <div class="col-sm-9">
                                    <select id="santri_id" name="santri_id" class="form-control" required>
                                        <option value="">(Pilih Santri)</option>
                                      @foreach($santri as $sn3)
                                        <option value="{{ $sn3->id }}">{{ $sn3->nama }}</option>
                                      @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="keperluan" class="col-sm-3 col-form-label">Keperluan</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="keperluan" name="keperluan" placeholder="Keperluan">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="jenis_surat" class="col-sm-3 col-form-label">Jenis Surat</label>
                                <div class="col-sm-9">
                                    <select id="jenis_surat" name="jenis_surat" class="form-control">
                                        <option value="1">Perizinan Keluar</option>
                                        <option value="2">Perizinan Pulang</option>

                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="offset-sm-3 col-sm-12">
                                    <button type="submit" class="btn btn-primary btn-block">Submit</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
            <!-- END BASIC TABLE -->
        </div>
        <div class="col-md-8">
            <!-- TABLE NO PADDING -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Data perizinan</h3>
                </div>
                <div class="panel-body">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Nama Santri</th>
                                <th>Alamat Santri</th>
                                <th>Keperluan</th>
                                <th>Jenis Surat</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($data_perizinan as $dp)
                            <tr>
                                <td>{{ $dp->santri->nama }}</td>
                                <td>{{ $dp->santri->alamat }}</td>
                                <td>{{ $dp->keperluan }}</td>
                                <td>
                                @if($dp->jenis_surat == 1)
                                  Izin Keluar
                                @else
                                  Izin Pulang
                                @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END TABLE NO PADDING -->
        </div>
    </div>
</div>
@endsection


