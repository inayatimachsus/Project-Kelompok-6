

<?php $__env->startSection('title', 'Kelola Keuangan'); ?>

<?php $__env->startSection('container'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">

        <div class="panel">    
        <div class="panel-heading">
            <div class="card-header"><i class="lnr lnr-layers"></i> Data Sumber</div>
            <div class="right">
            <button type="button" class="btn add" data-toggle="modal" data-target="#exampleModal">
                <i class="lnr lnr-plus-circle"></i>
            </button>
            </div>
        </div>
        <div class="panel-body">
            <div class="card-body">
                <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead class ="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Created At</th>
                            <th>Update At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($sb->nama_pemasukan); ?></td>
                            <td><?php echo e(date('d M Y', strtotime($sb->created_at))); ?></td>
                            <td><?php echo e(date('d M Y', strtotime($sb->updated_at))); ?></td>
                            <td>
                            <a href="<?php echo e(url('/kelola/'.$sb->id)); ?>" class = "btn btn-success btn-sm"><i class="lnr lnr-pencil"></i></a>                                       
                            <a href="#" class = "btn btn-danger btn-sm delete" sumber-id = "<?php echo e($sb->id); ?>"><i class="lnr lnr-trash"></i></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                        </div>
                    </div>        
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="lnr lnr-database"></i> Insert New</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action = "/kelola/create" method = "POST" enctype = "multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group <?php echo e($errors->has('nama_pemasukan') ? 'has-error' : ''); ?>">
                        <label for="exampleInputEmail1">Jenis Pemasukan</label>
                        <input type="text" class="form-control" id="name" aria-describedby="emailHelp" name = "nama_pemasukan" value = "<?php echo e(old('nama_pemasukan')); ?>">
                        <?php if($errors->has('nama_pemasukan')): ?>
                            <span class ="help-block"><?php echo e($errors->first('nama_pemasukan')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $('.delete').click(function(){
            var sumber_id = $(this).attr('sumber-id');
            swal({
                title: "Yakin?",
                text: "Apakah Akan di Hapus dengan ID "+sumber_id+"!?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                    console.log(willDelete);
                if (willDelete) {
                    window.location = "/kelola/"+sumber_id+"/delete";
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/sumber/sumber_index.blade.php ENDPATH**/ ?>