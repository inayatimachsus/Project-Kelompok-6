<body>
    <title>Laporan Pemasukan</title>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nominal</th>
                <th>Sumber</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e(date('d M Y',strtotime($pm->created_at))); ?></td>
                    <td>Rp. <?php echo e(number_format($pm->nominal,0)); ?></td>
                    <td><?php echo e($pm->nama_pemasukan); ?></td>
                    <td><?php echo e($pm->keterangan); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php /**PATH C:\xampp\htdocs\siakad\resources\views/laporan/laporan_pemasukan_excel.blade.php ENDPATH**/ ?>