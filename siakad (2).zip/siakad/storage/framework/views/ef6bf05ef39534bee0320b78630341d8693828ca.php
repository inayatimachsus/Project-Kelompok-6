

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('container'); ?>

<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Data Sementara</h3>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-users"></i></span>
										<p>
											<span class="number"><?php echo e(totalSantri()); ?></span>
											<span class="title">Jumlah Siswa</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-user"></i></span>
										<p>
											<span class="number"><?php echo e(totalGuru()); ?></span>
											<span class="title">Jumlah Guru</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-book"></i></span>
										<p>
											<span class="number"><?php echo e(totalMateri()); ?></span>
											<span class="title">Jumlah Materi</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-money"></i></span>
										<p>
											<span class="number"><?php echo e(totalSumber()); ?></span>
											<span class="title">Sumber Income</span>
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/dashboard/index.blade.php ENDPATH**/ ?>