

<?php $__env->startSection('title', 'Laporan Keuangan'); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <h3 class="page-title">Laporan Keuangan</h3>
    <div class="row">
        <div class="col-md-4">
            <!-- BASIC TABLE -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Insert Keuangan</h3>
                <div class = "right">
                    <a href="<?php echo e(url('/export-pemasukan')); ?>" class = "btn btn-success">Pemasukan</a>
                    <a href="<?php echo e(url('/export-pengeluaran')); ?>" class = "btn btn-success">Pengeluaran</a>
                </div>
                </div>
                <div class="panel-body">
                    <form action="<?php echo e(url('/cari-laporan')); ?>" method="GET">
                        <fieldset>
                        <?php echo e(csrf_field()); ?>

                            <div class = "dates">
                                <label>Dari</label>
                                <input type="text" autocomplete = "off" id="dari" class = "form-control" placeholder = "yyyy-mm-dd" name = "dari">
                            </div>
                            <div class = "dates">
                                <label>Sampai</label>
                                <input type="text" autocomplete = "off" id="dari" class = "form-control" placeholder = "yyyy-mm-dd" name = "sampai">
                            </div>
                            <div class="modal-footer">
                                <div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary btn-block">Search</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
            <!-- END BASIC TABLE -->
        </div>
        <div class="col-md-8">
            <!-- TABLE NO PADDING -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Data Pemasukan</h3>
                </div>
                <?php if(isset($pemasukan)): ?>
                <div class="panel-body">
                    <table class="table table-bordered" id="datatable2">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Nominal</th>
                                <th>Sumber</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e(date('d M Y',strtotime($pm->created_at))); ?></td>
                                <td>Rp. <?php echo e(number_format($pm->nominal,0)); ?></td>
                                <td><?php echo e($pm->nama_pemasukan); ?></td>
                                <td><?php echo e($pm->keterangan); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Data Pengeluaran</h3>
                </div>
                <?php if(isset($pengeluaran)): ?>
                <div class="panel-body">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Nominal</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e(date('d M Y',strtotime($pg->created_at))); ?></td>
                                <td>Rp. <?php echo e(number_format($pg->nominal,0)); ?></td>
                                <td><?php echo e($pg->keterangan); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>

            </div>
            <!-- END TABLE NO PADDING -->
        </div>
        <!-- END BASIC TABLE -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $(function(){
        $('.dates #dari').datepicker({
            'format':'yyyy-mm-dd',
            'autoclose':true
        });
    });
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/laporan/keuangan.blade.php ENDPATH**/ ?>