

<?php $__env->startSection('title', 'Details'); ?>

<?php $__env->startSection('header'); ?>
	<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
		<?php if(session('error')): ?>
            <div class="col-6">
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            </div>
        <?php endif; ?> 
	<div class="panel panel-profile">
		<div class="clearfix">
			<!-- LEFT COLUMN -->
				<div class="profile-left">
					<!-- PROFILE HEADER -->
						<div class="profile-header">
							<div class="overlay"></div>
								<div class="profile-main">
									<img src="" class="img-circle" alt="Avatar">
									<h3 class="name"><?php echo e($guru->nama); ?></h3>
									<span class="online-status status-available">Available</span>
								</div>
								</div>
								<div class="panel">
									<div class="profile-detail">
										<div class="profile-info">
											<h4 class="heading">Detail Info</h4>
											<ul class="list-unstyled list-justify">
												<li>No Telpon <span><?php echo e($guru->telepon); ?></span></li>
												<li>Status <span><?php echo e($guru->status); ?></span></li>
											</ul>
										</div>
									</div>
								</div>
                                
								<!-- END PROFILE DETAIL -->
							</div>
							<!-- END LEFT COLUMN -->
							<!-- RIGHT COLUMN -->
							<div class="profile-right">
								<!-- TABBED CONTENT -->
								<div class="tab-content">
								<div class="panel">
									<div class="panel-heading">
										<h3 class="panel-title">Mata Pelajaran</h3>
									</div>
									<div class="panel-body">
										<table class="table table-striped">
											<thead>
												<tr>
													<th>Kode</th>
													<th>Nama Materi</th>
													<th>Semester</th>
												</tr>
											</thead>
											<tbody>
												<?php $__currentLoopData = $guru->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($mapel->kode); ?></td>
													<td><?php echo e($mapel->nama); ?></td>
													<td><?php echo e($mapel->semester); ?></td>			
												</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
								<div class = "panel">
									<div id = "chartNilai"></div>
								</div>
								<!-- END TABBED CONTENT -->
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/guru/profile.blade.php ENDPATH**/ ?>