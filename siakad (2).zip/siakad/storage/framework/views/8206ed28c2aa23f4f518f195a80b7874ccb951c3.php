

<?php $__env->startSection('title', 'Perizinan'); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <h3 class="page-title">Tables</h3>
    <div class="row">
        <div class="col-md-4">
            <!-- BASIC TABLE -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Insert perizinan</h3>
                </div>
                <div class="panel-body">
                    <form action="/perizinan/print" method="POST" enctype="multipart/form-data">
                        <fieldset>
                        <?php echo e(csrf_field()); ?>

                            <div class="form-group row">
                                <label for="santri_id" class="col-sm-3 col-form-label">Santri</label>
                                <div class="col-sm-9">
                                    <select id="santri_id" name="santri_id" class="form-control" required>
                                        <option value="">(Pilih Santri)</option>
                                      <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sn3->id); ?>"><?php echo e($sn3->nama); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="keperluan" class="col-sm-3 col-form-label">Keperluan</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="keperluan" name="keperluan" placeholder="Keperluan">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="jenis_surat" class="col-sm-3 col-form-label">Jenis Surat</label>
                                <div class="col-sm-9">
                                    <select id="jenis_surat" name="jenis_surat" class="form-control">
                                        <option value="1">Perizinan Keluar</option>
                                        <option value="2">Perizinan Pulang</option>

                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="offset-sm-3 col-sm-12">
                                    <button type="submit" class="btn btn-primary btn-block">Submit</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
            <!-- END BASIC TABLE -->
        </div>
        <div class="col-md-8">
            <!-- TABLE NO PADDING -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Data perizinan</h3>
                </div>
                <div class="panel-body">
                    <table class="table table-bordered" id="datatable">
                        <thead>
                            <tr>
                                <th>Nama Santri</th>
                                <th>Alamat Santri</th>
                                <th>Keperluan</th>
                                <th>Jenis Surat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data_perizinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dp->santri->nama); ?></td>
                                <td><?php echo e($dp->santri->alamat); ?></td>
                                <td><?php echo e($dp->keperluan); ?></td>
                                <td>
                                <?php if($dp->jenis_surat == 1): ?>
                                  Izin Keluar
                                <?php else: ?>
                                  Izin Pulang
                                <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END TABLE NO PADDING -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/perizinan/index.blade.php ENDPATH**/ ?>