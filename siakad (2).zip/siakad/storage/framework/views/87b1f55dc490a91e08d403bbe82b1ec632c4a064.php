

<?php $__env->startSection('title', 'Update Data'); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
        <?php if(session('sukses')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('sukses')); ?>

                </div>
        <?php endif; ?> 
        <div class="panel">    
            <div class="panel-heading"><i class="lnr lnr-pencil"></i> Update</div>
        <div class="panel-body">
        <div class="row ml-3 mt-3">
            <div class="col-6">
                    <!-- Button trigger modal -->
                    <form action ="/kelola/<?php echo e($data->id); ?>/update" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                                <input name = "nama_pemasukan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder ="insert Name" 
                                value = "<?php echo e($data->nama_pemasukan); ?>">
                            </div>
                        <div class="modal-footer float-left">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                            <button type="submit" class="btn btn-warning">Update</button>  
                        </div>   
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/sumber/sumber_edit.blade.php ENDPATH**/ ?>