<table class="table" style="border:1px solid #ddd">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Lengkap</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Nilai</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($s->nama); ?></td>
            <td><?php echo e($s->gender); ?></td>
            <td><?php echo e($s->alamat); ?></td>
            <td><?php echo e($s->ratarata()); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\siakad\resources\views/export/exportpdf.blade.php ENDPATH**/ ?>