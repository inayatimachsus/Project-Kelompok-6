

<?php $__env->startSection('title', 'Update Data'); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
        <?php if(session('sukses')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('sukses')); ?>

                </div>
        <?php endif; ?> 
        <div class="panel">    
            <div class="panel-heading"><i class="lnr lnr-pencil"></i> Update</div>
        <div class="panel-body">
        <div class="row ml-3 mt-3">
            <div class="col-6">
                    <!-- Button trigger modal -->
                    <form action ="<?php echo e(url('pemasukan/'.$data->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Jenis Pemasukan</label>
                                    <select class="form-control" id="exampleFormControlSelect1" name = "sumber_id">
                                    <?php $__currentLoopData = $sumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sb->id); ?>"<?php echo e(($data->sumber_id == $sb->id ? 'selected' : '')); ?>><?php echo e($sb->nama_pemasukan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">                       
                                <label for="exampleInputEmail1">Nominal</label>
                                    <input name = "nominal" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder ="insert Name" 
                                    value = "<?php echo e($data->nominal); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Keterangan</label>
                                    <textarea name = "keterangan" class="form-control" id="exampleFormControlTextarea1" rows="3"><?php echo e($data->keterangan); ?></textarea>
                                </div>      
                                <div class="modal-footer float-left">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                                <button type="submit" class="btn btn-warning">Update</button>  
                        </div>   
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
</div>


 <?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/pemasukan/pemasukan_edit.blade.php ENDPATH**/ ?>