

<?php $__env->startSection('title', 'Details'); ?>

<?php $__env->startSection('header'); ?>
	<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
		<?php if(session('error')): ?>
            <div class="col-6">
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            </div>
        <?php endif; ?> 
	<div class="panel panel-profile">
		<div class="clearfix">
			<!-- LEFT COLUMN -->
				<div class="profile-left">
					<!-- PROFILE HEADER -->
						<div class="profile-header">
							<div class="overlay"></div>
								<div class="profile-main">
									<img src="<?php echo e($santri->getAvatar()); ?>" class="img-circle" alt="Avatar">
									<h3 class="name"><?php echo e($santri->nama); ?></h3>
									<span class="online-status status-available">Available</span>
								</div>
								<div class="profile-stat">
									<div class="row">
										<div class="col-md-4 stat-item">
											<?php echo e($santri->materi->count()); ?><span>Materi Kelas</span>
										</div>
									<div class="col-md-4 stat-item">
										15 <span>Awards</span>
											</div>
											<div class="col-md-4 stat-item">
												2174 <span>Points</span>
											</div>
										</div>
									</div>
								</div>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->
								<div class="panel">
									<div class="profile-detail">
										<div class="profile-info">
											<h4 class="heading">Detail Info</h4>
											<ul class="list-unstyled list-justify">
												<li>Jenis Kelamin <span><?php echo e($santri->gender); ?></span></li>
												<li>Alamat <span><?php echo e($santri->alamat); ?></span></li>
												<li>No Telepon <span><?php echo e($santri->no_telp); ?></span></li>
											</ul>
										</div>
										<div class="text-center"><a href="/santri/<?php echo e($santri->id); ?>/edit" class="btn btn-success">Edit Profile</a></div>
									</div>
								</div>
								<!-- END PROFILE DETAIL -->
							</div>
							<!-- END LEFT COLUMN -->
							<!-- RIGHT COLUMN -->
							<div class="profile-right">
							<!-- Button trigger modal -->
								<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
								Insert Nilai
								</button>
								<!-- TABBED CONTENT -->
								<div class="tab-content">
								<div class="panel">
									<div class="panel-heading">
										<h3 class="panel-title">Mata Pelajaran</h3>
									</div>
									<div class="panel-body">
										<table class="table table-striped">
											<thead>
												<tr>
													<th>Kode</th>
													<th>Nama Materi</th>
													<th>Semester</th>
													<th>Nilai</th>
													<th>Guru</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php $__currentLoopData = $santri->materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($mapel->kode); ?></td>
													<td><?php echo e($mapel->nama); ?></td>
													<td><?php echo e($mapel->semester); ?></td>
													<td><a href="#" class = "nilai" data-type="text" data-pk="<?php echo e($mapel->id); ?>" data-url="/api/santri/<?php echo e($santri->id); ?>/editnilai" data-title="Masukan Nilai"><?php echo e($mapel->pivot->nilai); ?></a></td>
													<td><a href="/guru/<?php echo e($mapel->guru_id); ?>/profile"><?php echo e($mapel->guru->nama); ?></a></td>				
													<td><a href="#" class = "btn btn-danger btn-sm deletenilai" santri-id = "<?php echo e($santri->id); ?>" mapel-id = "<?php echo e($mapel->id); ?>" mapel-name = "<?php echo e($mapel->nama); ?>"><i class="lnr lnr-trash"></i></a></td></td>					
												</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
								<div class = "panel">
									<div id = "chartNilai"></div>
								</div>
								<!-- END TABBED CONTENT -->
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel"><i class="lnr lnr-database"></i> Tambah Nilai</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body">
			<form action = "/santri/<?php echo e($santri->id); ?>/addnilai" method = "POST">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="mapel">Nama Mapel</label>
					<select class="form-control" id="mapel" name = "mapel">
					<?php $__currentLoopData = $mapelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value = "<?php echo e($mp->id); ?>"><?php echo e($mp->nama); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Nilai</label>
					<input type="text" class="form-control" id="nilai" aria-describedby="emailHelp" name ="nilai" placeholder = "Nilai">
					<?php if($errors->has('nilai')): ?>
						<span class ="help-block"><?php echo e($errors->first('nilai')); ?></span>
					<?php endif; ?>
				</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			<button type="submit" class="btn btn-primary">Save changes</button>
			</form>
		</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script>
		Highcharts.chart('chartNilai', {
		chart: {
			type: 'column'
		},
		title: {
			text: 'Laporan Nilai Santri'
		},
		xAxis: {
			categories: <?php echo json_encode($categories); ?>,
			crosshair: true
		},
		yAxis: {
			min: 0,
			title: {
				text: 'Range Nilai'
			}
		},
		tooltip: {
			headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			footerFormat: '</table>',
			shared: true,
			useHTML: true
		},
		plotOptions: {
			column: {
				pointPadding: 0.2,
				borderWidth: 0
			}
		},
		series: [{
			name: 'Nilai',
			data: <?php echo json_encode($data); ?>

		}]
	});
	
	$('.deletenilai').click(function(){
            var mapel_id = $(this).attr('mapel-id');
            var santri_id = $(this).attr('santri-id');
            var mapel_name = $(this).attr('mapel-name');
            swal({
                title: "Yakin?",
                text: "Apakah Akan di Hapus Nilai dari Pelajaran "+mapel_name+"!?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                    console.log(willDelete);
                if (willDelete) {
                    window.location = "/santri/"+santri_id+"/"+mapel_id+"/deletenilai";
                }
            });
        });

	$(document).ready(function() {
		$('.nilai').editable();
	});
</script>
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siakad\resources\views/santri/show.blade.php ENDPATH**/ ?>