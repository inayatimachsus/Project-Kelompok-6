<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pemasukan extends Model
{
    protected $table = 'pemasukan';
    protected $fillable = ['nominal', 'keterangan', 'tanggal', 'sumber_id'];

    public function sumber()
    {
        return $this->belongsTo(Sumber::class);
    }
}
