<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pengeluaran extends Model
{
    protected $table = 'pengeluaran';
    protected $fillable = ['nominal', 'keterangan', 'tanggal', 'pengeluaran_id'];

    public function sumberpengeluaran()
    {
        return $this->belongsTo(Sumberpengeluaran::class);
    }
}
