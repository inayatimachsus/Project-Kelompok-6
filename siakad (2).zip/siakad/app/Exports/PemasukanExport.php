<?php

namespace App\Exports;

use App\Pemasukan;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class PemasukanExport implements FromView
{
    public function view(): View
    {
        return view('laporan.laporan_pemasukan_excel', [
            'pemasukan' => Pemasukan::all(),
        ]);
    }
}
