<?php

namespace App\Exports;

use App\Pengeluaran;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class PengeluaranExport implements FromView
{
    public function view(): View
    {
        return view('laporan.laporan_pengeluaran_excel', [
            'pengeluaran' => Pengeluaran::all(),
        ]);
    }
}
