<?php

namespace App\Exports;

use App\Santri;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;

class SantriExport implements FromCollection, WithMapping, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Santri::all();
    }

    public function map($santri): array
    {
        return [
            $santri->nama,
            $santri->gender,
            $santri->alamat,
            $santri->ratarata()
        ];
    }

    public function headings(): array
    {
        return [
            'Nama Lengkap',
            'Jenis Kelamin',
            'Alamat',
            'Rata-Rata Nilai',
        ];
    }
}
