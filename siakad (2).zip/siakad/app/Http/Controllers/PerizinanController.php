<?php

namespace App\Http\Controllers;
use App\Perizinan;
use App\Santri;
use PDF;
use Illuminate\Http\Request;

class PerizinanController extends Controller
{

    public function index(Request $request)
    {

        $data_perizinan = Perizinan::with('santri')->get();
        $santri = Santri::all();
        
        return view('perizinan.index', ['data_perizinan' => $data_perizinan, 'santri'=>$santri]);
    }

    public function create(Request $request)
    {
        $request->request->add();
        $perizinan  = Perizinan::create($request->all());
        return redirect('/perizinan')->with('sukses', 'Data Berhasil DiInput');
    }

    public function update(Request $request, $id)
    {
        $perizinan = Perizinan::find($id);
        $perizinan->update($request->all());
        return redirect('/perizinan')->with('sukses', 'Data Berhasil Di Ubah');
    }

    public function delete($id)
    {
        $perizinan = Perizinan::find($id);
        $perizinan->delete();
        return redirect('/perizinan')->with('sukses', 'Data berhasil dihapus');
    }

    public function edit($id)
    {
        $perizinan = Perizinan::find($id);
        return view('perizinan/edit', ['perizinan' => $perizinan]);
    }

    public function print(Request $request)
    {
        $jenis_surat = $request->input('jenis_surat');
        $santri_id = $request->input('santri_id');
        $keperluan = $request->input('keperluan');
        $santri = Santri::find($santri_id);
        $pdf ='';

        Perizinan::create($request->all());
        
        if($santri_id == null){
            return back();
        }elseif($jenis_surat == 1){
            $pdf = PDF::loadview('perizinan/izin_keluar',['jenis_surat'=>$jenis_surat, 'santri'=>$santri, 'keperluan'=>$keperluan], );
        }else{
            $pdf = PDF::loadview('perizinan/izin_pulang',['jenis_surat'=>$jenis_surat, 'santri'=>$santri, 'keperluan'=>$keperluan], );
        }
        
    	return $pdf->stream();
    }
}
