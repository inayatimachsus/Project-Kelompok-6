<?php

namespace App\Http\Controllers;
use App\Materi;
use App\Guru;

use Illuminate\Http\Request;

class MateriController extends Controller
{

    public function index(Request $request)
    {
        if($request->has('cari'))
        {
            $data_materi = Materi::where('nama','LIKE','%'.$request->cari.'%')->paginate(10);
        }
        else
        {
            $data_materi = Materi::paginate(10);
        }
        $guru = Guru::all();
        return view('materi.index', ['data_materi' => $data_materi, 'guru' => $guru]);
    }

    public function profile($id)
    {
        $materi = Materi::find($id);
        return view('materi.profile', ['materi' => $materi]);
    }

    public function create(Request $request)
    {
        $request->request->add();
        $materi  = Materi::create($request->all());
        return redirect('/materi')->with('sukses', 'Data Berhasil DiInput');
    }

    public function update(Request $request, $id)
    {
        $materi = Materi::find($id);
        $materi->update($request->all());
        return redirect('/materi')->with('sukses', 'Data Berhasil Di Ubah');
    }

    public function delete($id)
    {
        $materi = Materi::find($id);
        $materi->delete();
        return redirect('/materi')->with('sukses', 'Data berhasil dihapus');
    }

    public function edit($id)
    {
        $materi = Materi::find($id);
        return view('materi/edit', ['materi' => $materi]);
    }
}
