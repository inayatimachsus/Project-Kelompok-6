<?php

namespace App\Http\Controllers;
use App\Guru;

use Illuminate\Http\Request;

class GuruController extends Controller
{

    public function index(Request $request)
    {
        if($request->has('cari'))
        {
            $data_guru = Guru::where('nama','LIKE','%'.$request->cari.'%')->paginate(10);
        }
        else
        {
            $data_guru = Guru::paginate(10);
        }
        return view('guru.index', ['data_guru' => $data_guru]);
    }

    public function profile($id)
    {
        $guru = Guru::find($id);
        return view('guru.profile', ['guru' => $guru]);
    }

    public function create(Request $request)
    {
        $request->request->add();
        $guru  = Guru::create($request->all());
        return redirect('/guru')->with('sukses', 'Data Berhasil DiInput');
    }

    public function update(Request $request, $id)
    {
        $guru = Guru::find($id);
        $guru->update($request->all());
        return redirect('/guru')->with('sukses', 'Data Berhasil Di Ubah');
    }

    public function delete($id)
    {
        $guru = Guru::find($id);
        $guru->delete();
        return redirect('/guru')->with('sukses', 'Data berhasil dihapus');
    }

    public function edit($id)
    {
        $guru = Guru::find($id);
        return view('guru/edit', ['guru' => $guru]);
    }
}
