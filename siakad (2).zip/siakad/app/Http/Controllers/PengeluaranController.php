<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pengeluaran;
use App\Sumberpengeluaran;
use DB;
use DataTables;

class PengeluaranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = \DB::table('pengeluaran as a')->join('sumberpengeluaran as b', 'a.pengeluaran_id', '=', 'b.id')->get();
        $sumberp = Sumberpengeluaran::get();

        return view('pengeluaran.pengeluaran_index', compact('data','sumberp'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->request->add();
        $pengeluaran  = Pengeluaran::create($request->all());
        return redirect('/pengeluaran')->with('sukses', 'Data Berhasil DiInput');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function yajra(Request $request)
    {
        DB::statement(DB::raw('set @rownum=0'));
        $pengeluaran = DB::table('pengeluaran as a')->join('sumberpengeluaran as b', 'a.pengeluaran_id', '=', 'b.id')->select([
            DB::raw('@rownum  := @rownum  + 1 AS rownum'),
            'a.id',
            'a.pengeluaran_id',
            'b.nama_pengeluaran',
            'a.nominal',
            'a.created_at',
            'a.keterangan']);
        $datatables = Datatables::of($pengeluaran)->addColumn('action', function ($pengeluaran) {
            return '<a href="#edit-'.$pengeluaran->id.'"class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i> Edit</a>
                    <a href="#destroy-'.$pengeluaran->id.'"class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-erase"></i> Delete</a>';
        })->editColumn('nominal', function($pengeluaran){
            $nominal = $pengeluaran->nominal;
            $nominal = 'Rp.'.number_format($nominal,0);
            $nominal = str_replace(',','.',$nominal);
            return $nominal;
        })->editColumn('created_at', function($pengeluaran){
            $tanggal = $pengeluaran->created_at;
            $tanggal = date('d M Y', strtotime($tanggal));
            return $tanggal;
        });

        // if ($keyword = $request->get('search')['value']) {
        //     $datatables->filterColumn('rownum', 'whereRaw', '@rownum  + 1 like ?', ["%{$keyword}%"]);
        // }

        return $datatables->make(true);
    }
}
