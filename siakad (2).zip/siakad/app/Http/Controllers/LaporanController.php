<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exports\PemasukanExport;
use Excel;


class LaporanController extends Controller
{
    public function index(){
        return view('laporan.keuangan');
    }
    public function cari(Request $request){
        $this->validate($request,[
            'dari' => 'required',
            'sampai' => 'required'
        ]);

        $dari = date('Y-m-d',strtotime($request->dari));
        $sampai = date('Y-m-d',strtotime($request->sampai));

        $pemasukan = \DB::table('pemasukan as p')->join('sumber as s','p.sumber_id','=','s.id')->whereBetween('p.created_at',[$dari,$sampai])->get();
        $total_pemasukan = \DB::table('pemasukan as p')->join('sumber as s','p.sumber_id','=','s.id')->whereBetween('p.created_at',[$dari,$sampai])->sum('nominal');
        $pengeluaran = \DB::table('pengeluaran')->whereBetween('created_at',[$dari,$sampai])->get();
        // dd($dari);

        return view('laporan.keuangan',compact('pemasukan','pengeluaran','total_pemasukan'));
    }
    // public function pemasukan(Request $request){
    //     $dari = date('Y-m-d',strtotime($request->dari));
    //     $sampai = date('Y-m-d',strtotime($request->sampai));
    //     $title = 'Laporan Pemasukan';
    //     $pemasukan = \DB::table('pemasukan as p')->join('sumber as s','p.sumber_id','=','s.id')->whereBetween('p.created_at',[$dari,$sampai])->get();
    //     $total_pemasukan = \DB::table('pemasukan as p')->join('sumber as s','p.sumber_id','=','s.id')->whereBetween('p.created_at',[$dari,$sampai])->sum('nominal');
        
    //     Excel::create($title, function($excel) use($pemasukan,$total_pemasukan) {
    //         $excel->sheet('Sheetname', function($sheet) use($pemasukan, $total_pemasukan) {
    //             $sheet->loadView('laporan.laporan_pemasukan_excel')->with('pemasukan',$pemasukan)->with('total_pemasukan',$total_pemasukan);
    //         });
    //     })->export('xls');
    // }
    public function pemasukan() 
    {
        return Excel::download(new PemasukanExport, 'Pemasukan.xlsx');
    }
    public function pengeluaran() 
    {
        return Excel::download(new PemasukanExport, 'Pengeluaran.xlsx');
    }
}