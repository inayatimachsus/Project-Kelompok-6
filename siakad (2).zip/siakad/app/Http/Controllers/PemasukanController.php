<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use DataTables;
use App\Sumber;
use App\Pemasukan;

class PemasukanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = \DB::table('pemasukan as a')->join('sumber as b', 'a.sumber_id', '=', 'b.id')->get();
        $sumber = Sumber::get();

        return view('pemasukan.pemasukan_index', compact('data','sumber'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->request->add();
        $pemasukan  = Pemasukan::create($request->all());
        return redirect('/pemasukan')->with('sukses', 'Data Berhasil DiInput');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = DB::table('pemasukan')->where('id',$id)->first();
        $sumber = DB::table('sumber')->get();

        return view('pemasukan.pemasukan_edit',compact('data','sumber'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'sumber_id' => 'required',
            'nominal' => 'required',
            'keterangan' => 'required'
        ]);
        DB::table('pemasukan')->where('sumber_id',$id)->update([
            'sumber_id'=>$request->sumber_id,
            'nominal'=>$request->nominal,
            'keterangan'=>$request->keterangan
        ]); 

        return redirect('pemasukan')>with('sukses', 'Data berhasil diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pemasukan = Pemasukan::find($id);
        $pemasukan->delete();
        return redirect('/pemasukan')->with('sukses', 'Data berhasil dihapus');
    }

    public function yajra(Request $request)
    {
        DB::statement(DB::raw('set @rownum=0'));
        $pemasukan = DB::table('pemasukan as a')->join('sumber as b', 'a.sumber_id', '=', 'b.id')->select([
            DB::raw('@rownum  := @rownum  + 1 AS rownum'),
            'a.id',
            'a.sumber_id',
            'b.nama_pemasukan',
            'a.nominal',
            'a.created_at',
            'a.keterangan']);
        $datatables = Datatables::of($pemasukan)->addColumn('action', function ($pemasukan) {
            $url_edit = url('pemasukan/'.$pemasukan->id);
            $url_hapus = url('pemasukan/'.$pemasukan->id.'/destroy');

            return '<a href="'.$url_edit.'"class="btn btn-xs btn-success"><i class="glyphicon glyphicon-edit"></i> Edit</a>
                    <a href="'.$url_hapus.'"class="btn btn-xs btn-danger delete" pemasukan-id = "{{$pemasukan->id}}"><i class="glyphicon glyphicon-erase"></i> Delete</a>';
        })->editColumn('nominal', function($pemasukan){
            $nominal = $pemasukan->nominal;
            $nominal = 'Rp.'.number_format($nominal,0);
            $nominal = str_replace(',','.',$nominal);
            return $nominal;
        })->editColumn('created_at', function($pemasukan){
            $tanggal = $pemasukan->created_at;
            $tanggal = date('d M Y', strtotime($tanggal));
            return $tanggal;
        });

        // if ($keyword = $request->get('search')['value']) {
        //     $datatables->filterColumn('rownum', 'whereRaw', '@rownum  + 1 like ?', ["%{$keyword}%"]);
        // }

        return $datatables->make(true);
    }
}
