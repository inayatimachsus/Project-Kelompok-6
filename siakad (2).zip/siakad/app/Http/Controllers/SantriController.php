<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Santri;
use App\Materi;
use Illuminate\Support\Str;
use App\Exports\SantriExport;
use Maatwebsite\Excel\Facades\Excel;
use PDF;

class SantriController extends Controller
{

    public function index(Request $request)
    {
        $data_santri = Santri::all();
        // if($request->has('cari'))
        // {
        //     $data_santri = Santri::where('nama','LIKE','%'.$request->cari.'%')->paginate(10);
        // }
        // else
        // {
        //     $data_santri = Santri::paginate(10);
        // }
        return view('santri.index', ['data_santri' => $data_santri]);
    }

    public function create(Request $request)
    {
        $this->validate($request, [
            'nama' => 'required|min:5',
            'email' => 'required|email|unique:users',
            'gender' => 'required',
            'alamat' => 'required',
            'avatar' => 'mimes:jpg,png|max:500'
        ]);
        //insert table user
        $user = new \App\User;
        $user->role = 'santri';
        $user->name = $request->nama;
        $user->email = $request->email;
        $user->password = bcrypt('rahasia');
        $user->remember_token = Str::random(60);
        $user->save();

        //insert table siswa
        $request->request->add(['user_id'=>$user->id]);
        $santri  = Santri::create($request->all());
        if($request->hasFile('avatar')){
            //memindahkan request file avatar ke folder public
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $santri->avatar = $request->file('avatar')->getClientOriginalName();
            $santri->save();
        }
        return redirect('/santri')->with('sukses', 'Data Berhasil DiInput');
    }

    public function store(Request $request)
    {
        //
    }

    public function edit($id)
    {
        $santri = Santri::find($id);
        return view('santri/edit', ['santri' => $santri]);
    }

    public function update(Request $request, $id)
    {
        $santri = Santri::find($id);
        $santri->update($request->all());
        if($request->hasFile('avatar')){
            //memindahkan request file avatar ke folder public
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $santri->avatar = $request->file('avatar')->getClientOriginalName();
            $santri->save();
        }
        return redirect('/santri')->with('sukses', 'Data Berhasil di Update');
    }

    public function delete($id)
    {
        $santri = Santri::find($id);
        $santri->delete();
        return redirect('/santri')->with('sukses', 'Data berhasil dihapus');
    }

    
    public function show($id)
    {
        $santri = Santri::find($id);
        $mapelajaran = Materi::all();
        //menyiapkan untuk chart
        $categories = [];
        $data = [];

        foreach($mapelajaran as $mp){
            //jika memiliki nilai mapel yang dilooping, kalo tidak lgsg ke nilai return
            if($santri->materi()->wherePivot('materi_id',$mp->id)->first()){
                $categories[] = $mp->nama;
                $data[] = $santri->materi()->wherePivot('materi_id',$mp->id)->first()->pivot->nilai;
            }
        }
        return view('santri.show',['santri' => $santri, 'mapelajaran' => $mapelajaran, 'categories' => $categories, 'data' => $data]);
    }

    public function addnilai(Request $request, $id)
    {
        $santri = Santri::find($id);
        $santri->materi()->attach($request->mapel,['nilai' => $request->nilai]);
        
        return redirect('santri/'.$id.'/show')->with('sukses', 'Data Nilai Berhasil Ditambahkan');
    }

    public function deletenilai($idsantri, $idmapel){
        $santri = Santri::find($idsantri);
        $santri->materi()->detach($idmapel);
        return redirect()->back()->with('sukses', 'Data Berhasil Di hapus');
    }

    public function exportExcel() 
    {
        return Excel::download(new SantriExport, 'Santri.xlsx');
    }

    public function exportPdf() 
    {
        $santri = Santri::all();
        $pdf = PDF::loadView('export.exportpdf', ['santri' => $santri]);
        return $pdf->download('Santri.pdf');
    }
}
