<?php

namespace App\Http\Controllers;
use App\Santri;
use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function editnilai(Request $request,$id)
    {
        $santri = Santri::find($id);
        //update nilai : 1. mengambil materi di database, dirubah         
        $santri->materi()->updateExistingPivot($request->pk, ['nilai' => $request->value]);
    }
}
