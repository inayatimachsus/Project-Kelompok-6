<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sumber extends Model
{
    protected $table = 'sumber';
    protected $fillable = ['nama_pemasukan', 'created_at', 'updated_at'];

    public function pemasukan()
    {
        return $this->hasMany(Pemasukan::class);
    }
}
