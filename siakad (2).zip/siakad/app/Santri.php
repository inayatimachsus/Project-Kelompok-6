<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Santri extends Model
{

    protected $table = 'santri';
    protected $fillable = [
        'nama', 'gender', 'alamat', 'no_telp', 'avatar','user_id'
    ];

    public function getAvatar(){
        if(!$this->avatar){
            return asset('images/default.jpg');
        }
        return asset('images/'.$this->avatar);
    }

    public function materi(){
        return $this->belongsToMany(Materi::class)->withPivot(['nilai'])->withTimeStamps();
    }

    public function ratarata()
    {
        // ambil nilai   
        $total = 0;
        $hitung = 0;
        foreach($this->materi as $materi){
           $total += $materi->pivot->nilai;
           $hitung++;
       }
       return $total!= 0? round($total/$hitung):$total; 
   }

   public function perizinan()
   {
       return $this->hasMany(Perizinan::class);
   }

   public function user()
    {
        return $this->belongsTo('App\User')->withDefault(['avatar' => 'default.jpg']);
    }
}