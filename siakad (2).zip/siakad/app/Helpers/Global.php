<?php

use App\Santri;
use App\Guru;
use App\Materi;
use App\Sumber;

function totalSantri()
{
    return Santri::count();
}
function totalGuru()
{
    return Guru::count();
}
function totalMateri()
{
    return Materi::count();
}
function totalSumber()
{
    return Sumber::count();
}
