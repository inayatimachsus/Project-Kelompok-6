<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sumberpengeluaran extends Model
{
    protected $table = 'sumberpengeluaran';
    protected $fillable = ['nama_pengeluaran', 'created_at', 'updated_at'];

    public function pengeluaran()
    {
        return $this->hasMany(Pengeluaran::class);
    }
}
