<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Perizinan extends Model
{
    protected $table = 'perizinan';
    
    protected $fillable = [
        'santri', 
        'keperluan', 
        'jenis_surat', 
        'santri_id'
    ];

    public function santri()
    {
        return $this->belongsTo(Santri::class);
    }

}
